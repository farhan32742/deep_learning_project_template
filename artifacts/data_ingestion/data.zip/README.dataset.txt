# Document Dectection > 2025-12-03 9:53pm
https://universe.roboflow.com/my-projects-y1nxu/document-dectection-3hw4l-pbj4s

Provided by a Roboflow user
License: CC BY 4.0

